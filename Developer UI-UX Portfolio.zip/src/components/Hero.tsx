import { ArrowDown } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen flex items-center justify-center bg-white px-6 relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWNobm9sb2d5JTIwYWJzdHJhY3R8ZW58MXx8fHwxNzMzMTY0MjQyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Hero background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-white/95 via-white/90 to-blue-950/20"></div>
      </div>
      
      <div className="max-w-6xl w-full relative z-10">
        <div className="text-center">
          <div className="mb-6 inline-block">
            <span className="bg-white/80 backdrop-blur-sm text-blue-900 px-4 py-2 rounded-full border border-gray-200 shadow-sm">
              Front-End Developer & UI/UX Designer
            </span>
          </div>
          
          <h1 className="mb-6 text-blue-950 leading-tight">
            I Turn Complex Problems Into
            <span className="block mt-2 bg-gradient-to-r from-teal-500 to-cyan-600 bg-clip-text text-transparent">
              Simple, Beautiful Solutions
            </span>
          </h1>
          
          <p className="text-gray-800 mb-10 max-w-2xl mx-auto text-lg">
            Where pixel-perfect design meets clean code. I create digital experiences that not only look stunning 
            but perform flawlessly across every device.
          </p>
          
          <div className="flex gap-4 justify-center flex-wrap">
            <button 
              onClick={scrollToProjects}
              className="bg-teal-500 text-white px-8 py-3 rounded-lg hover:bg-teal-600 transition-all hover:shadow-lg hover:scale-105"
            >
              View My Work
            </button>
            <a 
              href="#contact"
              className="border-2 border-blue-900 text-blue-900 bg-white/80 backdrop-blur-sm px-8 py-3 rounded-lg hover:bg-blue-50 transition-colors"
            >
              Get in Touch
            </a>
          </div>
        </div>
      </div>
      
      <button 
        onClick={scrollToProjects}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-teal-500 z-10"
        aria-label="Scroll down"
      >
        <ArrowDown size={32} />
      </button>
    </section>
  );
}
