
  # Developer UI-UX Portfolio

  This is a code bundle for Developer UI-UX Portfolio. The original project is available at https://www.figma.com/design/VxcLVELQO1by5wt1sQwjMr/Developer-UI-UX-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  